<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div><br />
        <?php endif; ?>
        <div class="row">
            <div class="col-md-2">
                <img class="img-responsive center-block" src="http://via.placeholder.com/200x200">
            </div>
            <div class="col-md-10">
                <h2 style="text-align: center;"><?php echo e(Auth::user()->name." ".Auth::user()->cognome); ?></h2>
                <div class="panel panel-default">
                    <div class="panel-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <form method="post" action="<?php echo e(action('UserController@update', Auth::id() )); ?>">
                            <?php echo e(csrf_field()); ?>

                            <input name="_method" type="hidden" value="PUT">
                            <h2>Your profile details</h2>
                            <div class="tab-content">
                                <div id="home" class="tab-pane fade in active">
                                    <p>
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>Firstname</th>
                                                        <th>Lastname</th>
                                                        <th>E-mail</th>
                                                        <th>Nationality</th>
                                                        <th>Affiliation</th>
                                                        <th>Research field</th>
                                                        <th>Phone</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td><input class="form-control" id="name" name="name" type="text" value="<?php echo e($u->name); ?>" /></td>
                                                            <td><input class="form-control" id="cognome" name="cognome" type="text" value="<?php echo e($u->cognome); ?>" /></td>
                                                            <td><input class="form-control" id="email" name="email" type="text" value="<?php echo e($u->email); ?>" /></td>
                                                            <td><input class="form-control" id="nazionalita" name="nazionalita" type="text" value="<?php echo e($u->nazionalita); ?>" /></td>
                                                            <td><input class="form-control" id="affiliazione" name="affiliazione" type="text" value="<?php echo e($u->affiliazione); ?>" /></td>
                                                            <td><input class="form-control" id="linea_ricerca" name="linea_ricerca" type="text" value="<?php echo e($u->linea_ricerca); ?>" /></td>
                                                            <td><input class="form-control" id="telefono" name="telefono" type="text" value="<?php echo e($u->telefono); ?>" /></td>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        <button class="btn btn-success" name="submit" type="submit">Update</button>
                                        </div>
                                        </p>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>